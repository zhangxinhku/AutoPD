      if taskname == "ipcas":
         fllist = proj_def_map.get("OUTPUT_FILES," + jobid, "").split()
         fllist.sort()
         pdblist = list()
         mtzlist = list()
         for flname in fllist:
            if flname.endswith(".pdb"):
               pdblist.append(os.path.join(proj_path,jobid,flname[:-4]))

            elif flname.endswith(".mtz"):
               mtzlist.append(os.path.join(proj_path, flname[:-4]))

#            elif flname.endswith(".log.html"):
#               self.ofiles.append(("SOLUTIONS", "text", os.path.join(proj_path, flname), "Solutions"))

            elif flname.endswith(".sum"):
               self.ofiles.append(("SUMMARY", "summary", os.path.join(proj_path, flname), "Summary"))

         cou = 0
         for pdbname in pdblist:
            if pdbname in mtzlist:
               only_name=pdbname.split('/')[-1]
               cou += 1
               self.ofiles.append(("LOG", "text", pdbname + ".log.html", only_name + "_log"))
               self.ofiles.append(("STRUCTURE%d" %(cou), "xyz:map", pdbname, "Solution %d and maps" %(cou)))

            else:
               self.ofiles.append(("XYZOUT_PART", "xyz", pdbname + ".pdb", "Partial Solution Ensemble"))

